# Number extraction > 2024-04-05 11:57pm
https://universe.roboflow.com/sambhavs-vision/number-extraction

Provided by a Roboflow user
License: CC BY 4.0

